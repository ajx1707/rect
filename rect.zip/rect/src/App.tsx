import styled from '@emotion/styled';

const Container = styled.div`
  min-height: 100vh;
  background: linear-gradient(135deg, #2A2D64 0%, #1D1F4A 100%);
  padding: 2rem;
`;

const Header = styled.div`
  text-align: center;
  margin: 2rem auto 4rem;
  max-width: 1200px;
`;

const HeaderText = styled.h1`
  color: #fff;
  font-size: 3.5rem;
  font-weight: 700;
  margin-bottom: 1rem;
  text-transform: uppercase;
  letter-spacing: 2px;
`;

const Subtitle = styled.p`
  color: #B8B9CF;
  font-size: 1.2rem;
  max-width: 600px;
  margin: 0 auto;
  line-height: 1.6;
`;

const EventsContainer = styled.div`
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 1rem;
`;

const EventCard = styled.div`
  background: rgba(255, 255, 255, 0.95);
  border-radius: 20px;
  padding: 2rem;
  transition: transform 0.3s ease, box-shadow 0.3s ease;
  cursor: pointer;
  display: flex;
  flex-direction: column;
  gap: 1rem;
  
  &:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
  }
`;

const EventHeader = styled.div`
  display: flex;
  align-items: center;
  gap: 1rem;
  margin-bottom: 0.5rem;
`;

const EventTitle = styled.h2`
  color: #2A2D64;
  font-size: 1.8rem;
  font-weight: 600;
  flex-grow: 1;
`;

const EventType = styled.span`
  background: #E5E6FF;
  color: #2A2D64;
  padding: 0.5rem 1rem;
  border-radius: 20px;
  font-size: 0.9rem;
  font-weight: 500;
  white-space: nowrap;
`;

const EventContent = styled.div`
  display: grid;
  grid-template-columns: 1fr auto;
  gap: 2rem;
  align-items: start;
`;

const EventDescription = styled.p`
  color: #666;
  font-size: 1rem;
  line-height: 1.6;
  max-width: 60ch;
`;

const EventDetails = styled.div`
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 1rem 2rem;
  padding: 1.5rem;
  background: #f8f9ff;
  border-radius: 12px;
  min-width: 300px;
`;

const DetailRow = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.3rem;
`;

const DetailLabel = styled.span`
  font-weight: 500;
  color: #2A2D64;
  font-size: 0.9rem;
`;

const DetailValue = styled.span`
  color: #555;
  font-size: 1rem;
`;

function App() {
  const events = [
    {
      title: "Code Quest",
      type: "Technical",
      description: "A competitive programming challenge where participants solve complex algorithmic problems. Test your coding skills against the best!",
      prize: "₹20,000",
      team: "2-3 members",
      venue: "CS Lab Complex",
      time: "10:00 AM - 2:00 PM"
    },
    {
      title: "Design Dynamo",
      type: "Creative",
      description: "Showcase your UI/UX design skills by creating innovative solutions for real-world problems. Let your creativity shine!",
      prize: "₹15,000",
      team: "Individual/Team",
      venue: "Design Studio",
      time: "11:00 AM - 3:00 PM"
    },
    {
      title: "Tech Talks",
      type: "Workshop",
      description: "Industry experts share insights on emerging technologies, AI, and the future of tech. Network with professionals and gain valuable knowledge.",
      prize: "Certificates",
      team: "Open to All",
      venue: "Main Auditorium",
      time: "2:00 PM - 5:00 PM"
    },
    {
      title: "Hackathon",
      type: "Technical",
      description: "24-hour coding marathon to build innovative solutions. Bring your ideas to life and compete for amazing prizes!",
      prize: "₹50,000",
      team: "4 members",
      venue: "Innovation Hub",
      time: "Starts at 9:00 AM"
    }
  ];

  return (
    <Container>
      <Header>
        <HeaderText>TECHNOVATE 2024</HeaderText>
        <Subtitle>
          Join us for the biggest technical symposium of the year. Showcase your skills, learn from experts, and win exciting prizes!
        </Subtitle>
      </Header>
      <EventsContainer>
        {events.map((event, index) => (
          <EventCard key={index}>
            <EventHeader>
              <EventTitle>{event.title}</EventTitle>
              <EventType>{event.type}</EventType>
            </EventHeader>
            <EventContent>
              <EventDescription>{event.description}</EventDescription>
              <EventDetails>
                <DetailRow>
                  <DetailLabel>Prize Pool</DetailLabel>
                  <DetailValue>{event.prize}</DetailValue>
                </DetailRow>
                <DetailRow>
                  <DetailLabel>Team Size</DetailLabel>
                  <DetailValue>{event.team}</DetailValue>
                </DetailRow>
                <DetailRow>
                  <DetailLabel>Venue</DetailLabel>
                  <DetailValue>{event.venue}</DetailValue>
                </DetailRow>
                <DetailRow>
                  <DetailLabel>Time</DetailLabel>
                  <DetailValue>{event.time}</DetailValue>
                </DetailRow>
              </EventDetails>
            </EventContent>
          </EventCard>
        ))}
      </EventsContainer>
    </Container>
  );
}

export default App;
