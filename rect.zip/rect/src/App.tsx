import styled from '@emotion/styled';

const Container = styled.div`
  min-height: 100vh;
  height: 100vh; // Fixed height
  background: linear-gradient(135deg, #2A2D64 0%, #1D1F4A 100%);
  display: flex;
  flex-direction: column;
  overflow: hidden; // Prevent page scroll
`;

const Header = styled.div`
  text-align: center;
  padding: 1.5rem 1rem;
  flex-shrink: 0; // Prevent header from shrinking
`;

const HeaderText = styled.h1`
  color: #fff;
  font-size: clamp(2rem, 5vw, 3.5rem);
  font-weight: 700;
  margin-bottom: 0.5rem;
  text-transform: uppercase;
  letter-spacing: 2px;
`;

const Subtitle = styled.p`
  color: #B8B9CF;
  font-size: clamp(0.9rem, 3vw, 1.2rem);
  max-width: 600px;
  margin: 0 auto;
  line-height: 1.6;
  padding: 0 1rem;
`;

const EventsContainer = styled.div`
  flex: 1; // Take remaining space
  display: flex;
  flex-direction: column;
  gap: 1rem;
  padding: 1rem;
  overflow-y: auto; // Enable scrolling
  max-width: 1200px;
  margin: 0 auto;
  width: 100%;

  /* Custom scrollbar */
  &::-webkit-scrollbar {
    width: 8px;
  }

  &::-webkit-scrollbar-track {
    background: rgba(255, 255, 255, 0.1);
    border-radius: 4px;
  }

  &::-webkit-scrollbar-thumb {
    background: rgba(255, 255, 255, 0.3);
    border-radius: 4px;
  }
`;

const EventCard = styled.div`
  background: rgba(255, 255, 255, 0.95);
  border-radius: 20px;
  padding: 1.5rem;
  transition: transform 0.3s ease, box-shadow 0.3s ease;
  cursor: pointer;
  
  &:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
  }

  @media (max-width: 768px) {
    padding: 1rem;
  }
`;

const EventHeader = styled.div`
  display: flex;
  align-items: center;
  gap: 1rem;
  margin-bottom: 1rem;
  flex-wrap: wrap;
`;

const EventTitle = styled.h2`
  color: #2A2D64;
  font-size: clamp(1.3rem, 4vw, 1.8rem);
  font-weight: 600;
  flex-grow: 1;
`;

const EventType = styled.span`
  background: #E5E6FF;
  color: #2A2D64;
  padding: 0.5rem 1rem;
  border-radius: 20px;
  font-size: 0.9rem;
  font-weight: 500;
  white-space: nowrap;
`;

const EventContent = styled.div`
  display: flex;
  flex-direction: column;
  gap: 1.5rem;

  @media (min-width: 768px) {
    flex-direction: row;
    align-items: start;
  }
`;

const EventDescription = styled.p`
  color: #666;
  font-size: 1rem;
  line-height: 1.6;
  flex: 1;

  @media (max-width: 768px) {
    font-size: 0.95rem;
  }
`;

const EventDetails = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(130px, 1fr));
  gap: 1rem;
  padding: 1.25rem;
  background: #f8f9ff;
  border-radius: 12px;
  width: 100%;

  @media (min-width: 768px) {
    min-width: 300px;
    width: auto;
  }
`;

const DetailRow = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.3rem;
`;

const DetailLabel = styled.span`
  font-weight: 500;
  color: #2A2D64;
  font-size: 0.85rem;
`;

const DetailValue = styled.span`
  color: #555;
  font-size: 0.95rem;
`;

function App() {
  const events = [
    {
      title: "Code Quest",
      type: "Technical",
      description: "A competitive programming challenge where participants solve complex algorithmic problems. Test your coding skills against the best!",
      prize: "₹20,000",
      team: "2-3 members",
      venue: "CS Lab Complex",
      time: "10:00 AM - 2:00 PM"
    },
    {
      title: "Design Dynamo",
      type: "Creative",
      description: "Showcase your UI/UX design skills by creating innovative solutions for real-world problems. Let your creativity shine!",
      prize: "₹15,000",
      team: "Individual/Team",
      venue: "Design Studio",
      time: "11:00 AM - 3:00 PM"
    },
    {
      title: "Tech Talks",
      type: "Workshop",
      description: "Industry experts share insights on emerging technologies, AI, and the future of tech. Network with professionals and gain valuable knowledge.",
      prize: "Certificates",
      team: "Open to All",
      venue: "Main Auditorium",
      time: "2:00 PM - 5:00 PM"
    },
    {
      title: "Hackathon",
      type: "Technical",
      description: "24-hour coding marathon to build innovative solutions. Bring your ideas to life and compete for amazing prizes!",
      prize: "₹50,000",
      team: "4 members",
      venue: "Innovation Hub",
      time: "Starts at 9:00 AM"
    }
  ];

  return (
    <Container>
      <Header>
        <HeaderText>TECHNOVATE 2024</HeaderText>
        <Subtitle>
          Join us for the biggest technical symposium of the year. Showcase your skills, learn from experts, and win exciting prizes!
        </Subtitle>
      </Header>
      <EventsContainer>
        {events.map((event, index) => (
          <EventCard key={index}>
            <EventHeader>
              <EventTitle>{event.title}</EventTitle>
              <EventType>{event.type}</EventType>
            </EventHeader>
            <EventContent>
              <EventDescription>{event.description}</EventDescription>
              <EventDetails>
                <DetailRow>
                  <DetailLabel>Prize Pool</DetailLabel>
                  <DetailValue>{event.prize}</DetailValue>
                </DetailRow>
                <DetailRow>
                  <DetailLabel>Team Size</DetailLabel>
                  <DetailValue>{event.team}</DetailValue>
                </DetailRow>
                <DetailRow>
                  <DetailLabel>Venue</DetailLabel>
                  <DetailValue>{event.venue}</DetailValue>
                </DetailRow>
                <DetailRow>
                  <DetailLabel>Time</DetailLabel>
                  <DetailValue>{event.time}</DetailValue>
                </DetailRow>
              </EventDetails>
            </EventContent>
          </EventCard>
        ))}
      </EventsContainer>
    </Container>
  );
}

export default App;
